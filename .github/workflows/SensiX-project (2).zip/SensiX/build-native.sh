#!/usr/bin/env bash
# Biên dịch helper native vào jniLibs (cần Android NDK)
set -e
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-$ANDROID_NDK_ROOT}}"
BIN="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
mkdir -p app/src/main/jniLibs/arm64-v8a app/src/main/jniLibs/armeabi-v7a
"$BIN/aarch64-linux-android26-clang" -O2 -fPIE -pie native/touchscale.c -o app/src/main/jniLibs/arm64-v8a/libtouchscale.so
"$BIN/armv7a-linux-androideabi26-clang" -O2 -fPIE -pie native/touchscale.c -o app/src/main/jniLibs/armeabi-v7a/libtouchscale.so

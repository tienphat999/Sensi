package com.example.sensi

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var proc: Process? = null
    private lateinit var shiz: TextView
    private lateinit var run: TextView
    private lateinit var lx: TextView
    private lateinit var ly: TextView
    private lateinit var sx: SeekBar
    private lateinit var sy: SeekBar
    private lateinit var region: RadioGroup
    private lateinit var rot: RadioGroup

    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    private fun gx() = 0.5f + sx.progress * 0.1f
    private fun gy() = 0.5f + sy.progress * 0.1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p * 2, p, p)
        }
        fun tv(s: String, size: Float = 15f) = TextView(this).apply {
            text = s; textSize = size; setPadding(0, p / 2, 0, p / 2)
        }
        fun bar(init: Int) = SeekBar(this).apply {
            max = 25; progress = init
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) = labels()
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        fun radios(base: Int, vararg names: String) = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            names.forEachIndexed { i, n -> addView(RadioButton(context).apply { text = n; id = base + i }) }
            check(base)
        }

        root.addView(tv("SensiX", 24f))
        shiz = tv(""); root.addView(shiz)

        ly = tv(""); root.addView(ly)
        sy = bar(10); root.addView(sy)
        lx = tv(""); root.addView(lx)
        sx = bar(9); root.addView(sx)

        root.addView(tv("Vùng áp dụng"))
        region = radios(100, "Phải", "Trái", "Tất cả"); root.addView(region)
        root.addView(tv("Hướng xoay màn hình khi chơi"))
        rot = radios(200, "Ngang 90°", "Ngang 270°"); root.addView(rot)

        root.addView(Button(this).apply { text = "Bật"; setOnClickListener { start() } })
        root.addView(Button(this).apply { text = "Tắt"; setOnClickListener { stop(); run.text = "Đã tắt" } })
        run = tv(""); root.addView(run)
        root.addView(tv(
            "Nếu cảm ứng bị ngược trục, đổi hướng xoay 90° ↔ 270° rồi bấm Bật lại. " +
                "Nhớ Tắt khi không chơi vì cài đặt áp dụng cho cả hệ thống.", 13f
        ))

        setContentView(ScrollView(this).apply { addView(root) })
        labels()
        Shizuku.addRequestPermissionResultListener(onPerm)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(onPerm)
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        // không dừng helper ở đây để nó vẫn chạy khi bạn vào game
    }

    private fun labels() {
        ly.text = "Độ nhạy Y: %.1f".format(gy())
        lx.text = "Độ nhạy X: %.1f".format(gx())
    }

    private fun refresh() {
        shiz.text = when {
            !Shizuku.pingBinder() -> "❌ Shizuku chưa chạy. Mở app Shizuku và khởi động nó."
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                "⚠️ Chưa cấp quyền Shizuku cho app này (bấm Bật để cấp)."
            else -> "✅ Shizuku sẵn sàng"
        }
    }

    private fun remoteExec(cmd: String): Process? = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    } catch (e: Exception) {
        null
    }

    private fun start() {
        refresh()
        if (!Shizuku.pingBinder()) return
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(1); return
        }
        val is90 = (rot.checkedRadioButtonId - 200) == 0
        val regIdx = region.checkedRadioButtonId - 100
        val (lo, hi) = when (regIdx) {
            0 -> if (is90) 0.5f to 1f else 0f to 0.5f     // nửa phải của màn hình
            1 -> if (is90) 0f to 0.5f else 0.5f to 1f     // nửa trái
            else -> 0f to 1f
        }
        // Màn hình cảm ứng gốc là dọc; khi chơi ngang: trục X màn hình = trục Y thô và ngược lại
        val cmd = "exec ${applicationInfo.nativeLibraryDir}/libtouchscale.so ${gy()} ${gx()} 1 $lo $hi"

        stop()
        val pr = remoteExec(cmd)
        if (pr == null) { run.text = "❌ Không chạy được lệnh qua Shizuku"; return }
        proc = pr
        run.text = "Đang khởi động…"
        thread {
            Thread.sleep(900)
            val dead = try { pr.exitValue(); true } catch (e: Exception) { false }
            val err = if (dead) pr.errorStream.bufferedReader().readText().trim() else ""
            runOnUiThread {
                run.text = if (dead) "❌ Helper dừng: $err"
                else "✅ Đang chạy (Y %.1f, X %.1f). Vào game để thử.".format(gy(), gx())
            }
        }
    }

    private fun stop() {
        proc?.destroy(); proc = null
        remoteExec("pkill -f '[l]ibtouchscale'")?.let { q ->
            thread { try { q.waitFor() } catch (_: Exception) {} }
        }
    }
}

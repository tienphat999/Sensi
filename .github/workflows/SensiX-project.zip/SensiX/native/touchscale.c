// touchscale: nhân quãng vuốt theo trục X/Y của màn hình cảm ứng (chạy bằng quyền shell qua Shizuku)
// usage: libtouchscale.so <gainRawX> <gainRawY> <regionAxis 0|1> <lo 0..1> <hi 0..1>
// Cách làm: giữ độc quyền thiết bị cảm ứng thật (EVIOCGRAB), đọc sự kiện, nhân phần di chuyển
// của ngón tay, rồi phát lại qua thiết bị ảo /dev/uinput. Nếu tiến trình chết, hệ thống tự nhả cảm ứng.
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define MAXSLOT 32
typedef struct { int have[2]; int inreg; float raw[2]; float out[2]; } Slot;

static volatile sig_atomic_t running = 1;
static void on_sig(int s) { (void)s; running = 0; }
static int bit(const unsigned char *a, int n) { return (a[n / 8] >> (n % 8)) & 1; }

static int open_touch(int need_direct) {
    char path[64];
    for (int i = 0; i < 40; i++) {
        snprintf(path, sizeof path, "/dev/input/event%d", i);
        int fd = open(path, O_RDONLY);
        if (fd < 0) continue;
        unsigned char abs[ABS_MAX / 8 + 1] = {0}, prop[INPUT_PROP_MAX / 8 + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs);
        ioctl(fd, EVIOCGPROP(sizeof prop), prop);
        if (bit(abs, ABS_MT_POSITION_X) && bit(abs, ABS_MT_POSITION_Y) && bit(abs, ABS_MT_SLOT) &&
            (!need_direct || bit(prop, INPUT_PROP_DIRECT)))
            return fd;
        close(fd);
    }
    return -1;
}

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: gainRawX gainRawY regionAxis lo hi\n"); return 1; }
    float gain[2] = { (float)atof(argv[1]), (float)atof(argv[2]) };
    int axis = atoi(argv[3]) ? 1 : 0;
    float lof = (float)atof(argv[4]), hif = (float)atof(argv[5]);

    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = on_sig;
    sigaction(SIGTERM, &sa, NULL); sigaction(SIGINT, &sa, NULL);

    int fd = open_touch(1);
    if (fd < 0) fd = open_touch(0);
    if (fd < 0) { fprintf(stderr, "khong tim thay man hinh cam ung\n"); return 2; }

    unsigned char abs[ABS_MAX / 8 + 1] = {0}, key[KEY_MAX / 8 + 1] = {0};
    ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs);
    ioctl(fd, EVIOCGBIT(EV_KEY, sizeof key), key);

    int ufd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (ufd < 0) { fprintf(stderr, "khong mo duoc /dev/uinput: %s\n", strerror(errno)); return 3; }

    struct uinput_user_dev ud; memset(&ud, 0, sizeof ud);
    snprintf(ud.name, UINPUT_MAX_NAME_SIZE, "touchscale");
    ud.id.bustype = BUS_VIRTUAL; ud.id.vendor = 1; ud.id.product = 1; ud.id.version = 1;
    ioctl(ufd, UI_SET_EVBIT, EV_SYN);
    ioctl(ufd, UI_SET_EVBIT, EV_ABS);
    ioctl(ufd, UI_SET_EVBIT, EV_KEY);
    ioctl(ufd, UI_SET_PROPBIT, INPUT_PROP_DIRECT);

    float amin[2] = {0, 0}, amax[2] = {0, 0};
    for (int c = 0; c <= ABS_MAX; c++) {
        if (!bit(abs, c)) continue;
        struct input_absinfo a;
        if (ioctl(fd, EVIOCGABS(c), &a) < 0) continue;
        ioctl(ufd, UI_SET_ABSBIT, c);
        ud.absmin[c] = a.minimum; ud.absmax[c] = a.maximum;
        ud.absfuzz[c] = a.fuzz;   ud.absflat[c] = a.flat;
        if (c == ABS_MT_POSITION_X) { amin[0] = a.minimum; amax[0] = a.maximum; }
        if (c == ABS_MT_POSITION_Y) { amin[1] = a.minimum; amax[1] = a.maximum; }
    }
    for (int k = 0; k <= KEY_MAX; k++) if (bit(key, k)) ioctl(ufd, UI_SET_KEYBIT, k);

    if (write(ufd, &ud, sizeof ud) != (ssize_t)sizeof ud || ioctl(ufd, UI_DEV_CREATE) < 0) {
        fprintf(stderr, "tao thiet bi ao that bai: %s\n", strerror(errno)); return 4;
    }
    usleep(400000); // chờ Android nhận thiết bị ảo trước khi chặn thiết bị thật
    if (ioctl(fd, EVIOCGRAB, 1) < 0) {
        fprintf(stderr, "EVIOCGRAB that bai: %s\n", strerror(errno));
        ioctl(ufd, UI_DEV_DESTROY); return 5;
    }

    float lo = amin[axis] + lof * (amax[axis] - amin[axis]);
    float hi = amin[axis] + hif * (amax[axis] - amin[axis]);
    Slot sl[MAXSLOT]; memset(sl, 0, sizeof sl);
    int cur = 0;
    struct pollfd pf = { fd, POLLIN, 0 };
    struct input_event buf[64];

    while (running) {
        if (poll(&pf, 1, 500) <= 0) continue;
        ssize_t n = read(fd, buf, sizeof buf);
        if (n <= 0) { if (errno == EINTR) continue; break; }
        int cnt = (int)(n / sizeof(struct input_event));
        for (int i = 0; i < cnt; i++) {
            struct input_event *e = &buf[i];
            if (e->type != EV_ABS) continue;
            if (e->code == ABS_MT_SLOT) {
                cur = e->value; if (cur < 0 || cur >= MAXSLOT) cur = 0;
            } else if (e->code == ABS_MT_TRACKING_ID) {
                if (e->value >= 0) { sl[cur].have[0] = sl[cur].have[1] = 0; sl[cur].inreg = 0; }
            } else if (e->code == ABS_MT_POSITION_X || e->code == ABS_MT_POSITION_Y) {
                int a = (e->code == ABS_MT_POSITION_Y);
                Slot *s = &sl[cur];
                float v = (float)e->value;
                if (!s->have[a]) {                     // điểm chạm đầu tiên: giữ nguyên vị trí
                    s->have[a] = 1; s->raw[a] = v; s->out[a] = v;
                    if (a == axis) s->inreg = (v >= lo && v <= hi);
                } else {                               // các lần di chuyển sau: nhân quãng vuốt
                    float d = v - s->raw[a]; s->raw[a] = v;
                    s->out[a] = s->inreg ? s->out[a] + d * gain[a] : v;
                    if (s->out[a] < amin[a]) s->out[a] = amin[a];
                    if (s->out[a] > amax[a]) s->out[a] = amax[a];
                }
                e->value = (int)(s->out[a] + 0.5f);
            }
        }
        if (write(ufd, buf, cnt * sizeof(struct input_event)) < 0) { /* bỏ qua */ }
    }

    ioctl(fd, EVIOCGRAB, 0);
    ioctl(ufd, UI_DEV_DESTROY);
    return 0;
}
